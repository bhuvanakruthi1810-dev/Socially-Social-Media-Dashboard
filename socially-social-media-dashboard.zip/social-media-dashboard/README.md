# Socially — Social Media Dashboard

A responsive social media dashboard built with HTML, CSS, and vanilla JavaScript, based on a beginner front-end dashboard project.

## Features
- Social account overview cards with follower/subscriber counts
- Daily engagement metrics such as views, likes, and retweets
- Dark/light theme toggle
- Remembers the selected theme using `localStorage`
- Responsive layout for desktop, tablet, and mobile screens
- Hover effects and clear visual indicators for increases/decreases

## How to run
1. Download and extract the ZIP file.
2. Open `index.html` in your browser.
3. Use the theme switch to change between light and dark mode.

No installation or build tools are required.

## Files
- `index.html` — dashboard structure
- `style.css` — styling, layout, themes, responsive rules
- `script.js` — theme toggle and follower total calculation

## JavaScript concepts demonstrated
Variables, arrays, `reduce()`, functions, conditionals, event listeners, DOM selection and updates, `localStorage`, and template-free DOM interaction.

## Note
The follower counts and engagement values are sample display data. This is a front-end demo; it does not connect to real social media accounts or fetch live analytics.
