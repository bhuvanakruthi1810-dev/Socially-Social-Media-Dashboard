const themeToggle = document.querySelector("#themeToggle");
const themeLabel = document.querySelector("#themeLabel");
const totalFollowers = document.querySelector("#totalFollowers");

// Restore the user's theme preference, if one was saved earlier.
const savedTheme = localStorage.getItem("socially-theme");
if (savedTheme === "dark") {
  document.body.classList.add("dark");
}

function updateThemeControl() {
  const isDark = document.body.classList.contains("dark");
  themeLabel.textContent = isDark ? "Light Mode" : "Dark Mode";
  themeToggle.setAttribute("aria-pressed", String(isDark));
  themeToggle.setAttribute("aria-label", isDark ? "Switch to light theme" : "Switch to dark theme");
}

themeToggle.addEventListener("click", () => {
  document.body.classList.toggle("dark");
  const isDark = document.body.classList.contains("dark");
  localStorage.setItem("socially-theme", isDark ? "dark" : "light");
  updateThemeControl();
});

updateThemeControl();

// Demo data: update this number when changing the sample account cards.
const followerCounts = [1248, 5846, 10200, 5710];
const total = followerCounts.reduce((sum, count) => sum + count, 0);
totalFollowers.textContent = total.toLocaleString("en-US");
